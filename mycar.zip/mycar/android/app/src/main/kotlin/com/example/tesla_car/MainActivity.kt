package com.example.makerlab_car

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
